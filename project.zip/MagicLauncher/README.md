# Magic Launcher (tablet-first MagicOS-style launcher)

Kotlin + Jetpack Compose, minSdk 29 (Android 10), targetSdk 35.

## Build
Push `project.zip` + `.github/workflows/build.yml` to GitHub; the workflow extracts the zip and builds
`app-debug.apk` (see the run's Artifacts). Locally: unzip, open in Android Studio, or `gradle assembleDebug`.
Set it as default Home app after install.

## Layout
| File | What |
|---|---|
| `ui/HomeScreen.kt` | pager desktop, drag-and-drop, edit mode, overlays |
| `ui/BigFolder.kt` | 1×1 / 2×2 (3×3 icons, +N overflow) / 2×1 (4×2) folders, direct-tap launch, blurred overlay |
| `ui/DynamicDock.kt` | pinned | divider | recents, spring-animated width, glass backdrop |
| `ui/WallpaperLayer.kt` | parallax wallpaper, RenderEffect blur (API 31+), pure-Kotlin box blur (API 29/30) |
| `ui/AppIcon.kt`, `ui/IconShapes.kt` | masked icons (circle/squircle/teardrop/rounded), icon packs |
| `ui/GestureContainer.kt` | swipe down/up, pinch-in, double-tap, per-item tap/drag |
| `ui/ContextMenu.kt` | long-press menu: LauncherApps shortcuts, app info, uninstall, folder styles |
| `ui/Widgets.kt` | AppWidgetHostView hosting, Clock/Weather/Battery/Storage cards, stacks, magnetic resize, picker |
| `ui/LaunchTransition.kt` | icon-bounds → fullscreen zoom and collapse on return home |
| `engine/GridEngine.kt` | collision displacement, free-slot search |
| `LauncherViewModel.kt` | StateFlow state, drag preview/merge/drop logic, persistence |

## Reference-style features
* Floating dock = two glass pills (pinned | recents); edge-to-edge mode = one bar with a divider.
* Drag an app from the desktop onto the pinned pill to pin it (pill highlights, icon shrinks into it);
  long-press-drag dock icons to reorder; drag one up out of the dock to put it back on the desktop.
* "Search" pill above the dock, bare Clock / Weather widgets, Search / Battery / Storage cards.
* Red notification badges on icons and folders (Notification access), 3×3 mini-preview on 1×1 folders.
* Label colour and status-bar icons switch automatically on bright wallpapers.
* In-app wallpaper picker (works on Android 13+ where system wallpaper can't be read).
* First-run setup guide (default home, usage access, notification access, gestures, wallpaper).
* Edge-flip glow while dragging to a screen edge, spring/pop/fade animations on every new element.

## Folder resizing
Long-press a folder → resize mode: frame with 4 edge + 4 corner handles. Drag a handle to grow/shrink in whole cells
(opposite edge stays put). Neighbours glide (eased tween) to the nearest vacant cells **on the same page**; if any of
them can't be re-seated the outline turns red, shakes, gives a reject haptic and the resize is refused. Pills at the
bottom: Open · Style (1×1 → 2×2 → 2×1) · Dissolve · Remove · Done. Dragging the folder body still moves it.
Widget resize and Style/“Create big folder” follow the same no-room rule.

## Known limits
* Not compiled in the authoring environment; expect small compile fixes on first build.
* Horizontal swipes starting on an App Widget are handed to the pager, but some widgets may still keep the gesture.
* App shortcuts require being the default Home app.
