package com.magiclauncher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magiclauncher.data.IconRepository
import com.magiclauncher.data.LoadedIcon
import com.magiclauncher.model.AppInfo
import com.magiclauncher.model.IconShape
import com.magiclauncher.model.LauncherSettings

/** Label / widget text colour: white on dark wallpapers, near-black on bright ones (animated by HomeScreen). */
val LocalLabelColor = compositionLocalOf { Color.White }

@Composable
fun AppGlyph(
    key: String, icons: IconRepository, version: Int, shape: IconShape, size: Dp,
    modifier: Modifier = Modifier, elevated: Boolean = false
) {
    val loaded by produceState<LoadedIcon?>(initialValue = icons.peek(key), key, version) { value = icons.load(key) }
    val clipShape = if (loaded?.masked == false) RectangleShape else shape.toShape()
    val shadowMod = if (elevated) Modifier.shadow(4.dp, clipShape, clip = false, ambientColor = Color.Black.copy(alpha = 0.3f), spotColor = Color.Black.copy(alpha = 0.3f)) else Modifier
    Box(modifier.size(size).then(shadowMod).clip(clipShape)) {
        val l = loaded
        if (l != null) Image(bitmap = l.bitmap, contentDescription = null, modifier = Modifier.fillMaxSize())
        else Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.12f)))
    }
}

/** Red notification badge; springs in/out when the count appears or disappears. */
@Composable
fun Badge(count: Int, modifier: Modifier = Modifier) {
    val scale by animateFloatAsState(if (count > 0) 1f else 0f, Springs.pop(), label = "badge")
    val last = remember { intArrayOf(count) }
    if (count > 0) last[0] = count
    if (scale > 0.01f) {
        Box(
            modifier.graphicsLayer { scaleX = scale; scaleY = scale }
                .defaultMinSize(20.dp, 20.dp).clip(CircleShape).background(Color(0xFFE5484D))
                .padding(horizontal = 5.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(if (last[0] > 99) "99+" else "${last[0]}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun AppLabel(text: String, modifier: Modifier = Modifier) {
    val c = LocalLabelColor.current
    Text(
        text, color = c, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        style = TextStyle(shadow = if (c == Color.White) Shadow(Color.Black.copy(alpha = 0.6f), blurRadius = 6f) else Shadow()),
        modifier = modifier.padding(horizontal = 4.dp)
    )
}

/** Visual only: all gestures live on the wrapper (see itemGestures). */
@Composable
fun AppIconCell(
    app: AppInfo, icons: IconRepository, version: Int, settings: LauncherSettings,
    w: Dp, h: Dp, modifier: Modifier = Modifier, badge: Int = 0
) {
    val base = minOf(minOf(w, h) * 0.58f, 76.dp) * settings.iconScale
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box {
            AppGlyph(app.key, icons, version, settings.iconShape, base, elevated = true)
            Badge(badge, Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp))
        }
        if (settings.showLabels) {
            Spacer(Modifier.height(6.dp))
            AppLabel(app.label)
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = 0.18f)), content = content)
}
