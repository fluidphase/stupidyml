package com.magiclauncher.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import com.magiclauncher.model.AppInfo

/**
 * Recently used apps: UsageStats events (needs "Usage access") merged with launches made from this launcher
 * (so the dock works even before the permission is granted).
 */
class RecentsRepository(private val ctx: Context) {
    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private val local = LinkedHashMap<String, Long>()

    fun record(pkg: String) = synchronized(local) { local[pkg] = System.currentTimeMillis() }

    fun hasUsageAccess(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) ==
            AppOpsManager.MODE_ALLOWED
    }

    fun query(apps: List<AppInfo>, excludePackages: Set<String>, max: Int): List<String> {
        val times = HashMap<String, Long>()
        synchronized(local) { times.putAll(local) }
        if (hasUsageAccess()) {
            try {
                val now = System.currentTimeMillis()
                val ev = usm.queryEvents(now - 3L * 24 * 3600 * 1000, now)
                val e = UsageEvents.Event()
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                        val prev = times[e.packageName] ?: 0L
                        if (e.timeStamp > prev) times[e.packageName] = e.timeStamp
                    }
                }
            } catch (e: Exception) { /* ignore */ }
        }
        val byPkg = apps.groupBy { it.packageName }
        return times.entries.sortedByDescending { it.value }.map { it.key }
            .filter { it != ctx.packageName && it !in excludePackages && byPkg.containsKey(it) }
            .take(max)
            .map { byPkg.getValue(it).first().key }
    }
}
