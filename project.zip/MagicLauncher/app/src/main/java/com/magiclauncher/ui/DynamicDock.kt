package com.magiclauncher.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import androidx.compose.ui.zIndex
import com.magiclauncher.data.IconRepository
import com.magiclauncher.model.AppInfo
import com.magiclauncher.model.LauncherSettings
import kotlinx.coroutines.launch
import kotlin.math.floor
import kotlin.math.roundToInt

sealed class DockEntry(val id: String) {
    class Pinned(val app: AppInfo) : DockEntry("p:${app.key}")
    class Recent(val app: AppInfo) : DockEntry("r:${app.key}")
    data object Divider : DockEntry("divider")
}

class DockCallbacks(
    val onTap: (AppInfo, Rect) -> Unit,
    val onMenu: (AppInfo) -> Unit,
    val onMenuClose: () -> Unit,
    val onReorder: (String, Int) -> Unit,
    val onDragOut: (AppInfo) -> Unit,
    val menuFor: @Composable (AppInfo) -> Unit
)

/**
 * Reference layout: floating mode = two separate glass pills (pinned | recents) with a gap; edge-to-edge mode = one
 * bar with a divider. Each pill springs to its new width; icons slide/fade (animateItem). Pinned icons can be
 * long-press-dragged to reorder, dragged up out of the dock onto the desktop, and apps dragged from the desktop
 * onto the pinned pill ([highlight]) are pinned.
 */
@Composable
fun DynamicDock(
    pinned: List<AppInfo>, recents: List<AppInfo>, settings: LauncherSettings,
    holder: WallpaperHolder, rootSize: IntSize, progress: () -> Float,
    icons: IconRepository, iconVersion: Int, badges: Map<String, Int>, bottomInset: Dp,
    highlight: Boolean, onPinnedBounds: (Rect) -> Unit, cb: DockCallbacks,
    modifier: Modifier = Modifier
) {
    val showRecents = settings.dockShowRecents && recents.isNotEmpty()
    val hl by animateFloatAsState(if (highlight) 1.06f else 1f, Springs.pop(), label = "dockHighlight")
    val pinnedEntries = pinned.map { DockEntry.Pinned(it) }
    val recentEntries = recents.map { DockEntry.Recent(it) }

    if (settings.dockFloating) {
        Row(
            modifier.padding(bottom = bottomInset + 14.dp).graphicsLayer { scaleX = hl; scaleY = hl },
            horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.Bottom
        ) {
            DockPill(pinnedEntries, false, 0.dp, settings, holder, rootSize, progress, icons, iconVersion, badges, highlight, onPinnedBounds, cb)
            AnimatedVisibility(
                showRecents,
                enter = fadeIn(tween(250)) + scaleIn(Springs.page(), initialScale = 0.75f) + expandHorizontally(Springs.page()),
                exit = fadeOut(tween(200)) + scaleOut(initialScale = 0.75f) + shrinkHorizontally()
            ) {
                DockPill(recentEntries, false, 0.dp, settings, holder, rootSize, progress, icons, iconVersion, badges, false, null, cb)
            }
        }
    } else {
        val all = buildList<DockEntry> {
            addAll(pinnedEntries)
            if (showRecents) { if (pinnedEntries.isNotEmpty()) add(DockEntry.Divider); addAll(recentEntries) }
        }
        DockPill(all, true, bottomInset, settings, holder, rootSize, progress, icons, iconVersion, badges, highlight, onPinnedBounds, cb, modifier)
    }
}

@Composable
private fun DockPill(
    entries: List<DockEntry>, fullWidth: Boolean, bottomInset: Dp, settings: LauncherSettings,
    holder: WallpaperHolder, rootSize: IntSize, progress: () -> Float,
    icons: IconRepository, iconVersion: Int, badges: Map<String, Int>,
    highlight: Boolean, onBounds: ((Rect) -> Unit)?, cb: DockCallbacks, modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val iconDp = 64.dp * settings.iconScale
    val slot = iconDp + 18.dp
    val dividerSlot = 22.dp
    val height = iconDp + 30.dp
    val shape = if (fullWidth) RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp) else RoundedCornerShape(38.dp)

    var total = 28.dp
    entries.forEach { total += if (it is DockEntry.Divider) dividerSlot else slot }
    val animW by animateDpAsState(total, Springs.page(), label = "pillWidth")
    var pos by remember { mutableStateOf(Offset.Zero) }
    var pillW by remember { mutableIntStateOf(0) }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOff by remember { mutableStateOf(Offset.Zero) }
    val slotPx = with(density) { slot.toPx() }
    val heightPx = with(density) { height.toPx() }
    val borderA by animateFloatAsState(if (highlight) 0.9f else 0f, tween(200), label = "pillBorder")

    val outer = if (fullWidth) Modifier.fillMaxWidth().height(height + bottomInset) else Modifier.width(animW).height(height)
    Box(modifier.then(outer).onSizeChanged { pillW = it.width }) {
        Box(
            Modifier.fillMaxSize().onGloballyPositioned {
                pos = it.positionInRoot()
                onBounds?.invoke(Rect(pos, it.size.toSize()))
            }
        ) { GlassBackdrop(Modifier.fillMaxSize(), shape, holder, rootSize, { pos }, progress, settings) }
        Box(Modifier.matchParentSize().border(2.dp, Color.White.copy(alpha = borderA), shape))

        LazyRow(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = if (fullWidth) bottomInset else 0.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            userScrollEnabled = false
        ) {
            items(entries, key = { it.id }) { e ->
                val app = when (e) { is DockEntry.Pinned -> e.app; is DockEntry.Recent -> e.app; else -> null }
                val dragged = app != null && app.key == dragKey
                val itemMod = if (dragged) Modifier else Modifier.animateItem(
                    fadeInSpec = tween(250), placementSpec = Springs.page(), fadeOutSpec = tween(200)
                )
                Box(
                    itemMod.width(if (e is DockEntry.Divider) dividerSlot else slot).height(iconDp + 30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (app == null) {
                        Box(Modifier.width(1.dp).height(iconDp * 0.6f).background(Color.White.copy(alpha = 0.38f)))
                    } else {
                        val pinnedIdx = entries.indexOf(e)
                        val pinnedCount = entries.count { it is DockEntry.Pinned }
                        DockIcon(
                            app, icons, iconVersion, settings, iconDp, badges[app.packageName] ?: 0,
                            draggable = e is DockEntry.Pinned, hidden = dragged, cb = cb,
                            onDragStart = { dragKey = app.key; dragOff = Offset.Zero },
                            onDrag = { d ->
                                dragOff += d
                                val idx = entries.indexOfFirst { it is DockEntry.Pinned && it.app.key == app.key }
                                if (idx >= 0) {
                                    val center = idx * slotPx + slotPx / 2f + dragOff.x
                                    val target = floor(center / slotPx).toInt().coerceIn(0, pinnedCount - 1)
                                    if (target != idx) {
                                        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                                        cb.onReorder(app.key, target)
                                        dragOff = dragOff.copy(x = dragOff.x - (target - idx) * slotPx)
                                    }
                                }
                            },
                            onDragEnd = {
                                val out = dragOff.y < -heightPx * 0.9f
                                if (out) { cb.onDragOut(app); dragKey = null; dragOff = Offset.Zero }
                                else scope.launch {      // spring back into its slot
                                    val a = Animatable(dragOff, Offset.VectorConverter)
                                    a.animateTo(Offset.Zero, Springs.page()) { dragOff = value }
                                    dragKey = null
                                }
                            }
                        )
                        if (pinnedIdx < 0) Unit
                    }
                }
            }
        }

        // the lifted icon is drawn here (outside the LazyRow clip) so it can leave the dock
        val dk = dragKey
        if (dk != null) {
            val idx = entries.indexOfFirst { it is DockEntry.Pinned && it.app.key == dk }
            val app = (entries.getOrNull(idx) as? DockEntry.Pinned)?.app
            if (app != null) {
                val contentW = with(density) { (total).toPx() }
                val start = (pillW - contentW) / 2f + with(density) { 14.dp.toPx() } + (slotPx - with(density) { iconDp.toPx() }) / 2f
                val x = start + idx * slotPx + dragOff.x
                val y = (heightPx - with(density) { iconDp.toPx() }) / 2f + dragOff.y
                val out = dragOff.y < -heightPx * 0.9f
                val s by animateFloatAsState(if (out) 1.25f else 1.12f, Springs.pop(), label = "lift")
                Box(
                    Modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) }.zIndex(10f)
                        .graphicsLayer { scaleX = s; scaleY = s; alpha = if (out) 0.85f else 1f }
                ) { AppGlyph(app.key, icons, iconVersion, settings.iconShape, iconDp, elevated = true) }
            }
        }
    }
}

@Composable
private fun DockIcon(
    app: AppInfo, icons: IconRepository, version: Int, settings: LauncherSettings, size: Dp, badge: Int,
    draggable: Boolean, hidden: Boolean, cb: DockCallbacks,
    onDragStart: () -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit
) {
    val view = LocalView.current
    val density = LocalDensity.current
    var pressed by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (pressed) 0.88f else 1f, Springs.pop(), label = "dockPress")
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val tap by rememberUpdatedState(cb.onTap)
    val menu by rememberUpdatedState(cb.onMenu)
    val closeMenu by rememberUpdatedState(cb.onMenuClose)
    val ds by rememberUpdatedState(onDragStart)
    val dr by rememberUpdatedState(onDrag)
    val de by rememberUpdatedState(onDragEnd)
    val slop = with(density) { 10.dp.toPx() }
    var started by remember { mutableStateOf(false) }
    var accum by remember { mutableStateOf(Offset.Zero) }

    Box(
        Modifier.graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (hidden) 0f else 1f }
            .onGloballyPositioned { bounds = it.boundsInWindow() }
            .pointerInput(app.key) {
                detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { tap(app, bounds) })
            }
            .pointerInput(app.key, draggable) {
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        started = false; accum = Offset.Zero
                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        menu(app)
                    },
                    onDrag = { c, d ->
                        c.consume()
                        if (draggable) {
                            if (!started) {
                                accum += d
                                if (accum.getDistance() > slop) { started = true; closeMenu(); ds(); dr(accum) }
                            } else dr(d)
                        }
                    },
                    onDragEnd = { if (started) de(); started = false },
                    onDragCancel = { if (started) de(); started = false }
                )
            }
    ) {
        AppGlyph(app.key, icons, version, settings.iconShape, size, elevated = true)
        Badge(badge, Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp))
        cb.menuFor(app)
    }
}
