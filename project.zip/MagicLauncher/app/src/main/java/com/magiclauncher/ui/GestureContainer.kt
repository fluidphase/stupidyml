package com.magiclauncher.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalViewConfiguration
import kotlin.math.abs

/**
 * Home-screen gestures: swipe down / swipe up / pinch-in. Detection never consumes events, so pagers, drags and
 * widgets still work; swipes are ignored when a child (pager, widget stack, drag) already consumed the movement.
 */
@Composable
fun GestureContainer(
    modifier: Modifier = Modifier,
    enabled: Boolean,
    swipeDown: Boolean,
    swipeUp: Boolean,
    pinch: Boolean,
    onSwipeDown: (startX: Float) -> Unit,
    onSwipeUp: () -> Unit,
    onPinchIn: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    val down by rememberUpdatedState(onSwipeDown)
    val up by rememberUpdatedState(onSwipeUp)
    val pin by rememberUpdatedState(onPinchIn)
    val threshold = LocalViewConfiguration.current.touchSlop * 6f

    Box(
        modifier
            .pointerInput(enabled && pinch) {
                if (!(enabled && pinch)) return@pointerInput
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var initial = 0f
                    var fired = false
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val pts = ev.changes.filter { it.pressed }
                        if (pts.size >= 2) {
                            val span = (pts[0].position - pts[1].position).getDistance()
                            if (initial == 0f) initial = span
                            else if (!fired && span < initial * 0.7f) { fired = true; pin() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .pointerInput(enabled, swipeDown, swipeUp) {
                if (!enabled || !(swipeDown || swipeUp)) return@pointerInput
                awaitEachGesture {
                    val first = awaitFirstDown(requireUnconsumed = false)
                    var fired = false
                    var multi = false
                    while (!fired) {
                        val ev = awaitPointerEvent()
                        if (ev.changes.any { it.isConsumed }) break
                        if (ev.changes.none { it.pressed }) break
                        if (ev.changes.size > 1) multi = true
                        if (multi) continue
                        val p = ev.changes.first().position
                        val dx = p.x - first.position.x
                        val dy = p.y - first.position.y
                        if (abs(dy) > threshold && abs(dy) > abs(dx) * 1.5f) {
                            if (dy > 0 && swipeDown) { fired = true; down(first.position.x) }
                            else if (dy < 0 && swipeUp) { fired = true; up() }
                            else break
                        }
                    }
                }
            },
        content = content
    )
}

/** Gestures for empty desktop space only (double-tap = lock, long-press = edit mode). Place as a *sibling behind* items. */
@Composable
fun Modifier.emptySpaceGestures(onDoubleTap: () -> Unit, onLongPress: () -> Unit, onTap: () -> Unit): Modifier {
    val dt by rememberUpdatedState(onDoubleTap)
    val lp by rememberUpdatedState(onLongPress)
    val tp by rememberUpdatedState(onTap)
    return pointerInput(Unit) {
        detectTapGestures(onDoubleTap = { dt() }, onLongPress = { lp() }, onTap = { tp() })
    }
}

/**
 * Per-item gestures. Tap is the OUTER detector, drag the INNER one, so a long-press never also fires a tap and the
 * drag keeps receiving events. Outside edit mode drags start after a long-press; in edit mode they start immediately.
 */
@Composable
fun Modifier.itemGestures(
    editMode: Boolean,
    onPress: (Boolean) -> Unit,
    onTap: (Offset) -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit
): Modifier {
    val press by rememberUpdatedState(onPress)
    val tap by rememberUpdatedState(onTap)
    val ds by rememberUpdatedState(onDragStart)
    val dr by rememberUpdatedState(onDrag)
    val de by rememberUpdatedState(onDragEnd)
    return this
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = { press(true); tryAwaitRelease(); press(false) },
                onTap = { tap(it) }
            )
        }
        .pointerInput(editMode) {
            if (editMode) {
                detectDragGestures(
                    onDragStart = { ds() },
                    onDrag = { c, d -> c.consume(); dr(d) },
                    onDragEnd = { de() },
                    onDragCancel = { de() }
                )
            } else {
                detectDragGesturesAfterLongPress(
                    onDragStart = { ds() },
                    onDrag = { c, d -> c.consume(); dr(d) },
                    onDragEnd = { de() },
                    onDragCancel = { de() }
                )
            }
        }
}
