package com.magiclauncher.model

import android.content.ComponentName
import android.os.UserHandle
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap

enum class ItemKind { APP, FOLDER, WIDGET }

enum class FolderStyle(val spanX: Int, val spanY: Int, val label: String) {
    STANDARD(1, 1, "Standard 1×1"),
    BIG(2, 2, "Big 2×2"),
    WIDE(2, 1, "Wide 2×1")
}

enum class MagicWidgetType(val label: String, val spanX: Int, val spanY: Int) {
    CLOCK("Clock", 3, 1),
    WEATHER("Weather", 2, 1),
    SEARCH("Search", 3, 1),
    BATTERY("Battery", 2, 1),
    STORAGE("Storage Manager", 2, 1)
}

enum class IconShape(val label: String) {
    CIRCLE("Circle"), SQUIRCLE("Squircle"), TEARDROP("Teardrop"), MAGIC_ROUNDED("MagicOS Rounded")
}

enum class SwipeUpAction(val label: String) { APP_DRAWER("App drawer"), GLOBAL_SEARCH("Global search") }

/** One widget inside a home item. A HomeItem with >1 WidgetRef is a swipeable widget stack. */
data class WidgetRef(val appWidgetId: Int = -1, val magic: MagicWidgetType? = null)

data class HomeItem(
    val id: String,
    val kind: ItemKind,
    val page: Int,
    val col: Int,
    val row: Int,
    val spanX: Int = 1,
    val spanY: Int = 1,
    val key: String? = null,                    // APP: "pkg/class"
    val children: List<String> = emptyList(),   // FOLDER: app keys
    val title: String = "",
    val folderStyle: FolderStyle = FolderStyle.STANDARD,
    val widgets: List<WidgetRef> = emptyList()  // WIDGET
)

data class AppInfo(
    val key: String,
    val packageName: String,
    val className: String,
    val label: String,
    val user: UserHandle
) {
    val component: ComponentName get() = ComponentName(packageName, className)
}

data class LauncherSettings(
    // desktop
    val gridCols: Int = 6,
    val gridRows: Int = 5,
    val parallax: Boolean = true,
    // icons
    val iconShape: IconShape = IconShape.MAGIC_ROUNDED,
    val iconScale: Float = 1f,
    val showLabels: Boolean = true,
    val iconPack: String? = null,
    // dock
    val dockBlurEnabled: Boolean = true,
    val dockBlurRadiusDp: Int = 20,
    val dockTintAlpha: Float = 0.22f,
    val dockShowRecents: Boolean = true,
    val dockMaxRecents: Int = 4,
    val dockFloating: Boolean = true,
    // gestures
    val gestureSwipeDown: Boolean = true,
    val gestureSwipeUp: Boolean = true,
    val swipeUpAction: SwipeUpAction = SwipeUpAction.APP_DRAWER,
    val gesturePinch: Boolean = true,
    val gestureDoubleTap: Boolean = true,
    // folders / widgets
    val defaultFolderStyle: FolderStyle = FolderStyle.BIG,
    val weatherLat: Double = 14.5995,
    val weatherLon: Double = 120.9842,
    // reference-style extras
    val showSearchPill: Boolean = true,
    val customWallpaper: Boolean = false,
    val setupDone: Boolean = false
)

data class DragState(
    val item: HomeItem,                 // snapshot at drag start (origin page / cell)
    val offset: Offset,                 // top-left of the dragged item in grid-area px
    val mergeTargetId: String? = null,
    val dropping: Boolean = false,
    val settleTo: Offset? = null,
    val shrink: Boolean = false          // dropped onto the dock: icon shrinks into it
)

data class LaunchAnim(val bounds: Rect, val icon: ImageBitmap?, val token: Long = System.nanoTime())
