package com.magiclauncher.ui

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.magiclauncher.LauncherViewModel
import com.magiclauncher.engine.Edge
import com.magiclauncher.model.HomeItem
import kotlin.math.roundToInt

fun View.rejectHaptic() {
    performHapticFeedback(if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS)
}

/**
 * Resize mode for a folder (entered by long-press): a frame with 4 edge handles and 4 corner handles, all inside the
 * item bounds so they receive touches. Dragging a handle live-previews the new size; neighbours glide to vacant cells.
 */
@Composable
fun FolderResizeHandles(item: HomeItem, vm: LauncherViewModel) {
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(320, easing = Easings.EmphasizedDecelerate)) }
    val t = 34.dp
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            alpha = appear.value
            val s = 0.94f + 0.06f * appear.value
            scaleX = s; scaleY = s
        }
    ) {
        Box(Modifier.matchParentSize().padding(2.dp).border(2.dp, Color.White.copy(alpha = 0.92f), RoundedCornerShape(30.dp)))
        val bar = Modifier.clip(CircleShape).background(Color.White)
        Handle(vm, Edge.L, Modifier.align(Alignment.CenterStart).fillMaxHeight().padding(vertical = t).width(t)) { Box(bar.size(5.dp, 30.dp)) }
        Handle(vm, Edge.R, Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(vertical = t).width(t)) { Box(bar.size(5.dp, 30.dp)) }
        Handle(vm, Edge.T, Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = t).height(t)) { Box(bar.size(30.dp, 5.dp)) }
        Handle(vm, Edge.B, Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = t).height(t)) { Box(bar.size(30.dp, 5.dp)) }
        val dot = Modifier.clip(CircleShape).background(Color.White)
        Handle(vm, Edge.TL, Modifier.align(Alignment.TopStart).size(t)) { Box(dot.size(13.dp)) }
        Handle(vm, Edge.TR, Modifier.align(Alignment.TopEnd).size(t)) { Box(dot.size(13.dp)) }
        Handle(vm, Edge.BL, Modifier.align(Alignment.BottomStart).size(t)) { Box(dot.size(13.dp)) }
        Handle(vm, Edge.BR, Modifier.align(Alignment.BottomEnd).size(t)) { Box(dot.size(13.dp)) }
    }
}

@Composable
private fun Handle(vm: LauncherViewModel, edge: Edge, modifier: Modifier, pill: @Composable () -> Unit) {
    var active by remember { mutableStateOf(false) }
    val sc = remember { Animatable(1f) }
    LaunchedEffect(active) { sc.animateTo(if (active) 1.35f else 1f, tween(180, easing = Easings.Standard)) }
    val view = LocalView.current
    Box(
        modifier.pointerInput(edge) {
            var acc = Offset.Zero
            detectDragGestures(
                onDragStart = { acc = Offset.Zero; active = true; view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); vm.resizeBegin() },
                onDrag = { c, d -> c.consume(); acc += d; vm.resizeUpdate(edge, acc) },
                onDragEnd = { active = false; vm.resizeEnd() },
                onDragCancel = { active = false; vm.resizeEnd() }
            )
        },
        contentAlignment = Alignment.Center
    ) { Box(Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value }) { pill() } }
}

/**
 * Page-level outline of the size being dragged (drawn outside the moving item). Blue = vacant space found,
 * red + shake + reject haptic = no room nearby, resize refused. Fades in/out with eased tweens.
 */
@Composable
fun ResizeGhost(vm: LauncherViewModel) {
    val view = LocalView.current
    val density = LocalDensity.current
    var last by remember { mutableStateOf<Rect?>(null) }
    val live = vm.resizeGhost
    SideEffect { if (live != null) last = live }
    val a = remember { Animatable(0f) }
    LaunchedEffect(live != null) { a.animateTo(if (live != null) 1f else 0f, tween(if (live != null) 160 else 240, easing = Easings.Standard)) }
    val ok = vm.resizeOk
    val shake = remember { Animatable(0f) }
    LaunchedEffect(ok) {
        if (!ok) {
            view.rejectHaptic()
            shake.animateTo(14f, tween(70, easing = Easings.Standard))
            shake.animateTo(-14f, tween(120, easing = Easings.Standard))
            shake.animateTo(8f, tween(100, easing = Easings.Standard))
            shake.animateTo(0f, tween(90, easing = Easings.Standard))
        }
    }
    val color by animateColorAsState(if (ok) Color(0xFF8AB4FF) else Color(0xFFFF6B6B), tween(180, easing = Easings.Standard), label = "ghostColor")
    val g = live ?: last
    if (g != null && a.value > 0.01f) {
        val w = with(density) { g.width.toDp() }
        val h = with(density) { g.height.toDp() }
        Box(
            Modifier.offset { IntOffset((g.left + shake.value).roundToInt(), g.top.roundToInt()) }
                .size(w, h).zIndex(5f).graphicsLayer { alpha = a.value }
                .clip(RoundedCornerShape(30.dp)).background(color.copy(alpha = 0.14f))
                .border(2.dp, color, RoundedCornerShape(30.dp))
        )
    }
}
