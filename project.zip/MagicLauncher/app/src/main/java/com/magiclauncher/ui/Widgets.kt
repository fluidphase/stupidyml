package com.magiclauncher.ui

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.view.View
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.togetherWith
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.magiclauncher.model.*
import com.magiclauncher.widget.LongPressHostView
import com.magiclauncher.widget.WidgetController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

// ------------------------------------------------------------------ widget body (single / stack)

@Composable
fun WidgetItem(
    item: HomeItem, widgets: WidgetController, settings: LauncherSettings, wDp: Dp, hDp: Dp,
    editMode: Boolean, onLongPress: () -> Unit, onMagicTap: (MagicWidgetType) -> Unit
) {
    if (item.widgets.size <= 1) {
        item.widgets.firstOrNull()?.let { WidgetBody(it, widgets, settings, wDp, hDp, onLongPress, onMagicTap) }
        return
    }
    val ps = rememberPagerState { item.widgets.size }
    Box(Modifier.fillMaxSize()) {
        VerticalPager(ps, Modifier.fillMaxSize(), userScrollEnabled = !editMode) { i ->
            WidgetBody(item.widgets[i], widgets, settings, wDp, hDp, onLongPress, onMagicTap)
        }
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 6.dp)) {
            repeat(item.widgets.size) { i ->
                Box(
                    Modifier.padding(2.dp).size(if (ps.currentPage == i) 7.dp else 5.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = if (ps.currentPage == i) 0.95f else 0.45f))
                )
            }
        }
    }
}

@Composable
private fun WidgetBody(
    ref: WidgetRef, widgets: WidgetController, settings: LauncherSettings, wDp: Dp, hDp: Dp,
    onLongPress: () -> Unit, onMagicTap: (MagicWidgetType) -> Unit
) {
    val lp by rememberUpdatedState(onLongPress)
    if (ref.magic != null) {
        val m = ref.magic
        val bg: Modifier = when (m) {
            MagicWidgetType.CLOCK, MagicWidgetType.WEATHER -> Modifier                       // bare, like the reference
            MagicWidgetType.SEARCH -> Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.42f))
            else -> Modifier.clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = 0.3f))
        }
        val pad = if (m == MagicWidgetType.SEARCH) PaddingValues(horizontal = 22.dp) else PaddingValues(12.dp)
        Box(
            Modifier.fillMaxSize().padding(4.dp).then(bg)
                .pointerInput(m) { detectTapGestures(onTap = { onMagicTap(m) }, onLongPress = { lp() }) }
                .padding(pad)
        ) {
            when (m) {
                MagicWidgetType.CLOCK -> ClockWidget()
                MagicWidgetType.WEATHER -> WeatherWidget(settings)
                MagicWidgetType.SEARCH -> SearchWidget()
                MagicWidgetType.BATTERY -> BatteryWidget()
                MagicWidgetType.STORAGE -> StorageWidget()
            }
        }
    } else {
        val w = wDp.value.toInt(); val h = hDp.value.toInt()
        AndroidView(
            factory = { ctx ->
                widgets.createView(ctx, ref.appWidgetId) ?: View(ctx)
            },
            update = { v ->
                (v as? LongPressHostView)?.onLongPress = { lp() }
                (v as? AppWidgetHostView)?.updateAppWidgetSize(null, w, h, w, h)
            },
            modifier = Modifier.fillMaxSize().padding(4.dp).clip(RoundedCornerShape(24.dp))
        )
    }
}

// ------------------------------------------------------------------ edit overlay (drag + magnetic resize)

private fun Modifier.overflowSize(w: Int, h: Int): Modifier = layout { m, _ ->
    val p = m.measure(Constraints.fixed(w.coerceAtLeast(1), h.coerceAtLeast(1)))
    layout(0, 0) { p.place(0, 0) }
}

@Composable
fun WidgetEditOverlay(
    item: HomeItem, selected: Boolean, cellW: Float, cellH: Float, cols: Int, rows: Int,
    onSelect: () -> Unit, onPress: (Boolean) -> Unit,
    onDragStart: () -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit,
    onResize: (Int, Int) -> Unit, onRemove: () -> Unit, onUnstack: () -> Unit
) {
    val density = LocalDensity.current
    var raw by remember { mutableStateOf<Offset?>(null) }
    val baseW = item.spanX * cellW
    val baseH = item.spanY * cellH
    Box(
        Modifier.fillMaxSize().padding(2.dp).clip(RoundedCornerShape(26.dp))
            .border(if (selected) 2.dp else 1.dp, Color.White.copy(alpha = if (selected) 0.95f else 0.45f), RoundedCornerShape(26.dp))
            .itemGestures(true, onPress, { onSelect() }, onDragStart, onDrag, onDragEnd)
    ) {
        if (selected) {
            Row(Modifier.align(Alignment.TopCenter).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (item.widgets.size > 1) Chip("Unstack", Color(0xCC3B3FD9), onUnstack)
                Chip("Remove", Color(0xCCE5484D), onRemove)
            }
        }
    }
    if (selected) {
        // magnetic resize handle: displayed frame is pulled toward the snapped cell size
        val r = raw
        if (r != null) {
            val sx = ((baseW + r.x) / cellW).roundToInt().coerceIn(1, cols - item.col)
            val sy = ((baseH + r.y) / cellH).roundToInt().coerceIn(1, rows - item.row)
            val snappedW = sx * cellW; val snappedH = sy * cellH
            val dw = snappedW + (baseW + r.x - snappedW) * 0.25f
            val dh = snappedH + (baseH + r.y - snappedH) * 0.25f
            Box(
                Modifier.overflowSize(dw.roundToInt(), dh.roundToInt())
                    .border(2.dp, Color(0xFF8AB4FF), RoundedCornerShape(26.dp))
                    .background(Color(0x228AB4FF), RoundedCornerShape(26.dp))
            )
        }
        Box(
            Modifier.fillMaxSize().padding(2.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(Color.White)
                    .pointerInput(item.id, item.spanX, item.spanY) {
                        var acc = Offset.Zero
                        detectDragGestures(
                            onDragStart = { acc = Offset.Zero; raw = Offset.Zero },
                            onDrag = { c, d -> c.consume(); acc += d; raw = acc },
                            onDragEnd = {
                                val sx = ((baseW + acc.x) / cellW).roundToInt().coerceIn(1, cols - item.col)
                                val sy = ((baseH + acc.y) / cellH).roundToInt().coerceIn(1, rows - item.row)
                                raw = null
                                if (sx != item.spanX || sy != item.spanY) onResize(sx, sy)
                            },
                            onDragCancel = { raw = null }
                        )
                    },
                contentAlignment = Alignment.Center
            ) { Text("⇲", color = Color.Black, fontSize = 18.sp) }
        }
    }
}

@Composable
private fun Chip(text: String, bg: Color, onClick: () -> Unit) {
    Text(
        text, color = Color.White, fontSize = 12.sp,
        modifier = Modifier.clip(CircleShape).background(bg)
            .pointerInput(Unit) { detectTapGestures { onClick() } }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

// ------------------------------------------------------------------ Magic widgets (adaptive text colour)

@Composable
private fun ClockWidget() {
    val c = LocalLabelColor.current
    val time by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(1000 - value % 1000) }
    }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val date = remember { SimpleDateFormat("EEEE, d. MMMM", Locale.getDefault()) }
    val text = hm.format(Date(time))
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        // each digit slides/fades when it changes (minute roll-over animation)
        Row(verticalAlignment = Alignment.Bottom) {
            text.forEachIndexed { i, ch ->
                androidx.compose.animation.AnimatedContent(
                    targetState = ch, label = "digit$i",
                    transitionSpec = {
                        (androidx.compose.animation.slideInVertically(Springs.shift()) { it / 2 } + androidx.compose.animation.fadeIn()) togetherWith
                            (androidx.compose.animation.slideOutVertically { -it / 2 } + androidx.compose.animation.fadeOut())
                    }
                ) { Text("$it", color = c, fontSize = 58.sp, fontWeight = FontWeight.Light) }
            }
        }
        Text(date.format(Date(time)), color = c, fontSize = 17.sp)
    }
}

private data class Weather(val temp: Int, val code: Int)

private fun fetchWeather(lat: Double, lon: Double): Weather? = try {
    val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code")
    val c = url.openConnection() as HttpURLConnection
    c.connectTimeout = 8000; c.readTimeout = 8000
    val text = c.inputStream.bufferedReader().use { it.readText() }
    val cur = JSONObject(text).getJSONObject("current")
    Weather(cur.getDouble("temperature_2m").roundToInt(), cur.getInt("weather_code"))
} catch (e: Exception) { null }

private fun describe(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "Clear"
    1, 2, 3 -> "⛅" to "Partly cloudy"
    45, 48 -> "🌫️" to "Fog"
    in 51..57 -> "🌦️" to "Drizzle"
    in 61..67 -> "🌧️" to "Rain"
    in 71..77 -> "❄️" to "Snow"
    in 80..82 -> "🌦️" to "Showers"
    in 95..99 -> "⛈️" to "Thunderstorm"
    else -> "🌡️" to "Weather"
}

@Composable
private fun WeatherWidget(settings: LauncherSettings) {
    val c = LocalLabelColor.current
    val w by produceState<Weather?>(null, settings.weatherLat, settings.weatherLon) {
        while (true) {
            value = withContext(Dispatchers.IO) { fetchWeather(settings.weatherLat, settings.weatherLon) } ?: value
            delay(if (value == null) 60_000L else 1_800_000L)
        }
    }
    val cur = w
    val pop by androidx.compose.animation.core.animateFloatAsState(if (cur != null) 1f else 0.6f, Springs.pop(), label = "weatherPop")
    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
        if (cur == null) {
            Text("🌡️", fontSize = 34.sp)
        } else {
            val (emoji, _) = describe(cur.code)
            Text("${cur.temp}°", color = c, fontSize = 26.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.width(8.dp))
            Text(emoji, fontSize = 40.sp, modifier = Modifier.graphicsLayer { scaleX = pop; scaleY = pop })
        }
    }
}

@Composable
private fun SearchWidget() {
    val c = LocalLabelColor.current
    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Text("🔍", fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Text("Search", color = c.copy(alpha = 0.75f), fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text("🎙", fontSize = 20.sp)
    }
}

@Composable
private fun RingWidget(fraction: Float, title: String, value: String, ringColor: Color) {
    val c = LocalLabelColor.current
    val f by androidx.compose.animation.core.animateFloatAsState(fraction.coerceIn(0f, 1f), Springs.page(), label = "ring")
    Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.fillMaxHeight().aspectRatio(1f).padding(4.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 9.dp.toPx()
                val s = Size(size.width - sw, size.height - sw)
                drawArc(c.copy(alpha = 0.2f), 0f, 360f, false, Offset(sw / 2, sw / 2), s, style = Stroke(sw))
                drawArc(ringColor, -90f, 360f * f, false, Offset(sw / 2, sw / 2), s, style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = c.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(value, color = c, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun BatteryWidget() {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(100) }
    var charging by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0) level = (l * 100f / s).roundToInt()
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            }
        }
        val sticky = ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        sticky?.let { r.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(r) }
    }
    RingWidget(level / 100f, if (charging) "Charging ⚡" else "Battery", "$level%", if (level <= 20 && !charging) Color(0xFFFF6B6B) else Color(0xFF3DBE6B))
}

@Composable
private fun StorageWidget() {
    val (used, total) = remember {
        val st = StatFs(Environment.getDataDirectory().path)
        val t = st.blockCountLong * st.blockSizeLong
        (t - st.availableBytes) to t
    }
    fun gb(b: Long) = String.format(Locale.getDefault(), "%.0f", b / 1_000_000_000.0)
    RingWidget(used.toFloat() / total.toFloat(), "Storage", "${gb(used)} / ${gb(total)} GB", Color(0xFF4C8DFF))
}

// ------------------------------------------------------------------ widget picker (side panel for tablets)

@Composable
fun WidgetPicker(
    widgets: WidgetController, cellW: Float, cellH: Float, cols: Int, rows: Int,
    onMagic: (MagicWidgetType) -> Unit, onProvider: (AppWidgetProviderInfo, Int, Int) -> Unit, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val providers by produceState(emptyList<AppWidgetProviderInfo>()) {
        value = withContext(Dispatchers.Default) { widgets.providers() }
    }
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } }) {
        Column(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(440.dp).background(Color(0xF0181A20))
                .pointerInput(Unit) { detectTapGestures { } }
                .windowInsetsPadding(WindowInsets.systemBars).padding(20.dp)
        ) {
            Text("Widgets & Magic Cards", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Text("Magic Cards", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp) }
                items(MagicWidgetType.entries.toList()) { t ->
                    PickerRow(t.label, "${t.spanX}×${t.spanY}", null) { onMagic(t) }
                }
                item { Spacer(Modifier.height(8.dp)); Text("App widgets", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp) }
                items(providers, key = { it.provider.flattenToString() }) { info ->
                    val sx = ceil(info.minWidth.toFloat() / cellW).toInt().coerceIn(1, cols)
                    val sy = ceil(info.minHeight.toFloat() / cellH).toInt().coerceIn(1, rows)
                    val preview by produceState<ImageBitmap?>(null, info) {
                        value = withContext(Dispatchers.Default) {
                            runCatching {
                                (info.loadPreviewImage(ctx, 0) ?: info.loadIcon(ctx, 0))?.toBitmap(256, 160)?.asImageBitmap()
                            }.getOrNull()
                        }
                    }
                    PickerRow(info.loadLabel(ctx.packageManager).toString(), "$sx×$sy", preview) { onProvider(info, sx, sy) }
                }
            }
        }
    }
}

@Composable
private fun PickerRow(title: String, size: String, preview: ImageBitmap?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.08f))
            .pointerInput(Unit) { detectTapGestures { onClick() } }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (preview != null) Image(preview, null, Modifier.size(96.dp, 60.dp)) else Box(Modifier.size(96.dp, 60.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Color.White, maxLines = 1)
            Text(size, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }
}
