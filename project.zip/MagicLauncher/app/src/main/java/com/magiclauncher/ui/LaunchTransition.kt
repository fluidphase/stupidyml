package com.magiclauncher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.magiclauncher.model.LaunchAnim
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Shared-element zoom: a rounded rect starts exactly on the tapped icon's window bounds and springs to full screen.
 * When the user comes back home (ON_RESUME after a pause) it collapses back onto the icon.
 */
@Composable
fun LaunchTransition(anim: LaunchAnim, onDone: () -> Unit) {
    val progress = remember(anim.token) { Animatable(0f) }
    var paused by remember(anim.token) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val owner = LocalLifecycleOwner.current
    val density = LocalDensity.current

    fun collapse() { scope.launch { progress.animateTo(0f, Springs.page()); onDone() } }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { paused = true }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { if (paused) collapse() }
    LaunchedEffect(anim.token) {
        progress.animateTo(1f, Springs.page())
        delay(1800)   // launch failed / app slow: still resumed and never paused -> collapse
        if (!paused && owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) collapse()
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val full = Rect(0f, 0f, constraints.maxWidth.toFloat(), constraints.maxHeight.toFloat())
        val p = progress.value.coerceIn(0f, 1.04f)
        fun l(a: Float, b: Float) = a + (b - a) * p
        val w = l(anim.bounds.width, full.width).coerceAtLeast(1f)
        val h = l(anim.bounds.height, full.height).coerceAtLeast(1f)
        val corner = with(density) { (24.dp.toPx() * (1f - p.coerceIn(0f, 1f))).toDp() }
        Box(
            Modifier.offset { IntOffset(l(anim.bounds.left, 0f).roundToInt(), l(anim.bounds.top, 0f).roundToInt()) }
                .size(with(density) { w.toDp() }, with(density) { h.toDp() })
                .clip(RoundedCornerShape(corner)).background(Color(0xFF14151A)),
            contentAlignment = Alignment.Center
        ) {
            anim.icon?.let {
                Image(
                    it, null,
                    Modifier.size(with(density) { minOf(w, h).times(0.5f).toDp() })
                        .graphicsLayer { alpha = (1f - p * 1.4f).coerceIn(0f, 1f) }
                )
            }
        }
    }
}
