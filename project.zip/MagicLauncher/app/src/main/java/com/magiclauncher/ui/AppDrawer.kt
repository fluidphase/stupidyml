package com.magiclauncher.ui

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.magiclauncher.data.IconRepository
import com.magiclauncher.model.AppInfo
import com.magiclauncher.model.LauncherSettings
import kotlinx.coroutines.delay

@Composable
fun AppDrawer(
    apps: List<AppInfo>, icons: IconRepository, version: Int, settings: LauncherSettings,
    holder: WallpaperHolder, focusSearch: Boolean,
    onLaunch: (AppInfo, Rect) -> Unit, onAddHome: (AppInfo) -> Unit, onPin: (AppInfo) -> Unit,
    onInfo: (AppInfo) -> Unit, onUninstall: (AppInfo) -> Unit, onWebSearch: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) { if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) } }
    val focus = remember { FocusRequester() }
    val view = LocalView.current
    LaunchedEffect(focusSearch) { if (focusSearch) { delay(250); runCatching { focus.requestFocus() } } }
    val api31 = Build.VERSION.SDK_INT >= 31

    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize().then(if (api31) Modifier.blur(28.dp) else Modifier)) {
            drawWallpaper(if (api31) holder.image else (holder.heavy ?: holder.image), 0.5f, false, size.width, size.height)
            drawRect(Color.Black.copy(alpha = 0.5f))
        }
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 48.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search apps & the web") }, singleLine = true, shape = CircleShape,
                modifier = Modifier.align(Alignment.CenterHorizontally).widthIn(max = 560.dp).fillMaxWidth()
                    .padding(vertical = 16.dp).focusRequester(focus),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    val first = filtered.firstOrNull()
                    if (first != null) onLaunch(first, Rect.Zero)
                    else if (query.isNotBlank()) onWebSearch(query)
                })
            )
            if (filtered.isEmpty() && query.isNotBlank()) {
                Text(
                    "Search the web for “$query”", color = Color.White,
                    modifier = Modifier.align(Alignment.CenterHorizontally).pointerInput(query) { detectTapGestures { onWebSearch(query) } }.padding(24.dp)
                )
            }
            LazyVerticalGrid(GridCells.Adaptive(120.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
                items(filtered, key = { it.key }) { app ->
                    var bounds by remember { mutableStateOf(Rect.Zero) }
                    var menu by remember { mutableStateOf(false) }
                    Box(
                        Modifier.padding(8.dp).onGloballyPositioned { bounds = it.boundsInWindow() }
                            .pointerInput(app.key) {
                                detectTapGestures(
                                    onTap = { onLaunch(app, bounds) },
                                    onLongPress = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); menu = true }
                                )
                            }
                    ) {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            AppGlyph(app.key, icons, version, settings.iconShape, 64.dp * settings.iconScale)
                            Spacer(Modifier.height(6.dp))
                            AppLabel(app.label)
                        }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("Add to Home screen") }, { menu = false; onAddHome(app) })
                            DropdownMenuItem({ Text("Pin to dock") }, { menu = false; onPin(app) })
                            DropdownMenuItem({ Text("App info") }, { menu = false; onInfo(app) })
                            DropdownMenuItem({ Text("Uninstall") }, { menu = false; onUninstall(app) })
                        }
                    }
                }
            }
        }
    }
}
