package com.magiclauncher.ui

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.core.graphics.drawable.toBitmap
import com.magiclauncher.model.LauncherSettings
import com.magiclauncher.util.BoxBlur
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Stable
class WallpaperHolder {
    var image by mutableStateOf<ImageBitmap?>(null)
    var blurred by mutableStateOf<ImageBitmap?>(null)   // dock-radius blur (API < 31 only)
    var heavy by mutableStateOf<ImageBitmap?>(null)     // 24dp blur for folder overlay / drawer (API < 31 only)
    var isLight by mutableStateOf(false)                // bright wallpaper -> dark labels / dark status-bar icons
    var fade by mutableFloatStateOf(1f)                 // cross-fade when the wallpaper changes
    internal var wallpaperId = -1
}

private fun loadWallpaper(ctx: android.content.Context, custom: Boolean): ImageBitmap? {
    if (custom) {
        val f = java.io.File(ctx.filesDir, "wallpaper.jpg")
        if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.path)?.let { return it.asImageBitmap() }
    }
    return try {
        val d = WallpaperManager.getInstance(ctx).drawable ?: return null
        val iw = d.intrinsicWidth.coerceAtLeast(1); val ih = d.intrinsicHeight.coerceAtLeast(1)
        val s = min(1f, 2200f / max(iw, ih))
        d.toBitmap(max(1, (iw * s).toInt()), max(1, (ih * s).toInt())).asImageBitmap()
    } catch (e: Throwable) { null }
}

private fun blurImage(img: ImageBitmap, radiusPx: Float): ImageBitmap {
    val bmp = img.asAndroidBitmap()
    val small = Bitmap.createScaledBitmap(bmp, max(1, bmp.width / 4), max(1, bmp.height / 4), true)
    return BoxBlur.blur(small, (radiusPx / 4f).roundToInt().coerceAtLeast(1)).asImageBitmap()
}

@Composable
fun rememberWallpaper(dockBlurRadiusDp: Int, reloadKey: Int, custom: Boolean): WallpaperHolder {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    val holder = remember { WallpaperHolder() }

    LaunchedEffect(reloadKey, custom) {
        holder.wallpaperId = -1
        if (custom) {
            holder.image = withContext(Dispatchers.IO) { loadWallpaper(ctx, true) }
            return@LaunchedEffect
        }
        val wm = WallpaperManager.getInstance(ctx)
        while (true) {
            val id = try { wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM) } catch (e: Exception) { 0 }
            if (id != holder.wallpaperId) {
                holder.wallpaperId = id
                holder.image = withContext(Dispatchers.IO) { loadWallpaper(ctx, false) }
            }
            delay(2500)
        }
    }
    // smooth cross-fade + luminance detection whenever the wallpaper changes
    LaunchedEffect(holder.image) {
        val img = holder.image
        holder.isLight = if (img == null) false else withContext(Dispatchers.Default) {
            val s = Bitmap.createScaledBitmap(img.asAndroidBitmap(), 16, 16, true)
            var sum = 0.0
            for (x in 0 until 16) for (y in 0 until 16) {
                val p = s.getPixel(x, y)
                sum += 0.299 * android.graphics.Color.red(p) + 0.587 * android.graphics.Color.green(p) + 0.114 * android.graphics.Color.blue(p)
            }
            sum / 256.0 > 150.0
        }
        holder.fade = 0f
        androidx.compose.animation.core.Animatable(0f).animateTo(1f, androidx.compose.animation.core.tween(600)) { holder.fade = value }
    }
    // API 29/30 fallback: pre-blurred copies of the wallpaper (RenderEffect doesn't exist before API 31).
    LaunchedEffect(holder.image) {
        val img = holder.image
        if (Build.VERSION.SDK_INT < 31 && img != null) {
            holder.heavy = withContext(Dispatchers.Default) { blurImage(img, 24f * density) }
        }
    }
    LaunchedEffect(holder.image, dockBlurRadiusDp) {
        val img = holder.image
        if (Build.VERSION.SDK_INT < 31 && img != null && dockBlurRadiusDp > 0) {
            delay(150)
            holder.blurred = withContext(Dispatchers.Default) { blurImage(img, dockBlurRadiusDp * density) }
        }
    }
    return holder
}

/** Draws the wallpaper cover-fit in a [width]x[height] viewport with optional parallax shift. */
fun DrawScope.drawWallpaper(img: ImageBitmap?, progress: Float, parallax: Boolean, width: Float, height: Float, alpha: Float = 1f) {
    if (img == null) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF1B2735), Color(0xFF3A1C71))), size = androidx.compose.ui.geometry.Size(width, height), alpha = alpha)
        return
    }
    val zoom = if (parallax) 1.15f else 1f
    val scale = max(width / img.width, height / img.height) * zoom
    val dw = img.width * scale; val dh = img.height * scale
    val x = -(dw - width) * (if (parallax) progress else 0.5f)
    val y = -(dh - height) / 2f
    drawImage(
        img,
        srcOffset = IntOffset.Zero, srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset(x.roundToInt(), y.roundToInt()), dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
        alpha = alpha,
        filterQuality = FilterQuality.Medium
    )
}

/**
 * Glassmorphism backdrop: draws the same wallpaper (same parallax) that sits behind the dock, blurred.
 * API 31+: real-time RenderEffect. API 29/30: pre-blurred bitmap sampled at the dock's screen position.
 */
@Composable
fun GlassBackdrop(
    modifier: Modifier,
    shape: Shape,
    holder: WallpaperHolder,
    rootSize: IntSize,
    topLeft: () -> Offset,
    progress: () -> Float,
    settings: LauncherSettings
) {
    val density = LocalDensity.current.density
    val api31 = Build.VERSION.SDK_INT >= 31
    val blurOn = settings.dockBlurEnabled && settings.dockBlurRadiusDp > 0
    val radiusPx = settings.dockBlurRadiusDp * density
    Box(modifier.clip(shape).border(1.dp, Color.White.copy(alpha = 0.22f), shape)) {
        val layer = if (api31 && blurOn) {
            Modifier.graphicsLayer {
                renderEffect = BlurEffect(radiusPx, radiusPx, TileMode.Clamp)
                clip = true
            }
        } else Modifier
        Canvas(Modifier.matchParentSize().then(layer)) {
            val img = if (api31 || !blurOn) holder.image else (holder.blurred ?: holder.image)
            val p = topLeft()
            translate(-p.x, -p.y) {
                drawWallpaper(img, progress(), settings.parallax, rootSize.width.toFloat(), rootSize.height.toFloat())
            }
        }
        Box(Modifier.matchParentSize().background(Color.White.copy(alpha = settings.dockTintAlpha)))
    }
}
