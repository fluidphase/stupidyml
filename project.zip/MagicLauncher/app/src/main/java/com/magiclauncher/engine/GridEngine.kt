package com.magiclauncher.engine

import com.magiclauncher.model.HomeItem
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.min
import kotlin.math.roundToInt

/** Pure grid logic: collision resolution ("items slide out of the way"), free-slot search, page compaction. */
object GridEngine {

    private fun free(g: Array<BooleanArray>, c: Int, r: Int, sx: Int, sy: Int, cols: Int, rows: Int): Boolean {
        if (c < 0 || r < 0 || c + sx > cols || r + sy > rows) return false
        for (rr in r until r + sy) for (cc in c until c + sx) if (g[rr][cc]) return false
        return true
    }

    private fun mark(g: Array<BooleanArray>, c: Int, r: Int, sx: Int, sy: Int) {
        for (rr in r until r + sy) for (cc in c until c + sx) g[rr][cc] = true
    }

    private fun clamp(i: HomeItem, cols: Int, rows: Int): HomeItem {
        val sx = min(i.spanX, cols).coerceAtLeast(1)
        val sy = min(i.spanY, rows).coerceAtLeast(1)
        return i.copy(
            spanX = sx, spanY = sy,
            col = i.col.coerceIn(0, cols - sx),
            row = i.row.coerceIn(0, rows - sy)
        )
    }

    /**
     * Places [moving] (if any) at its requested cell and pushes every colliding item to the nearest free
     * slot (overflowing to later pages). Items that don't collide keep their position, so the result can be
     * used directly as a live drag preview.
     */
    fun place(items: List<HomeItem>, moving: HomeItem?, cols: Int, rows: Int): List<HomeItem> {
        val grids = HashMap<Int, Array<BooleanArray>>()
        fun grid(p: Int) = grids.getOrPut(p) { Array(rows) { BooleanArray(cols) } }
        val out = ArrayList<HomeItem>(items.size + 1)
        if (moving != null) {
            val m = clamp(moving, cols, rows)
            mark(grid(m.page), m.col, m.row, m.spanX, m.spanY)
            out.add(m)
        }
        val displaced = ArrayList<HomeItem>()
        val others = items.filter { it.id != moving?.id }
            .sortedWith(compareBy({ it.page }, { it.row }, { it.col }))
        for (o0 in others) {
            val o = clamp(o0, cols, rows)
            val g = grid(o.page)
            if (free(g, o.col, o.row, o.spanX, o.spanY, cols, rows)) {
                mark(g, o.col, o.row, o.spanX, o.spanY); out.add(o)
            } else displaced.add(o)
        }
        for (o in displaced) out.add(relocate(o, { p -> grid(p) }, cols, rows))
        return out
    }

    private fun relocate(o: HomeItem, grid: (Int) -> Array<BooleanArray>, cols: Int, rows: Int): HomeItem {
        var p = o.page
        while (true) {
            val g = grid(p)
            var best: IntArray? = null
            var bestD = Int.MAX_VALUE
            for (r in 0..(rows - o.spanY)) for (c in 0..(cols - o.spanX)) {
                if (free(g, c, r, o.spanX, o.spanY, cols, rows)) {
                    val dc = c - o.col; val dr = r - o.row
                    val d = dc * dc + dr * dr
                    if (d < bestD) { bestD = d; best = intArrayOf(c, r) }
                }
            }
            if (best != null) {
                mark(g, best[0], best[1], o.spanX, o.spanY)
                return o.copy(page = p, col = best[0], row = best[1])
            }
            p++
        }
    }

    /** First free slot (page, col, row) scanning from [startPage]; always succeeds (appends a page if needed). */
    fun firstFree(items: List<HomeItem>, startPage: Int, sx0: Int, sy0: Int, cols: Int, rows: Int): Triple<Int, Int, Int> {
        val sx = min(sx0, cols); val sy = min(sy0, rows)
        val grids = HashMap<Int, Array<BooleanArray>>()
        fun grid(p: Int) = grids.getOrPut(p) { Array(rows) { BooleanArray(cols) } }
        for (i in items) {
            val c = clamp(i, cols, rows)
            mark(grid(c.page), c.col, c.row, c.spanX, c.spanY)
        }
        val maxPage = (items.maxOfOrNull { it.page } ?: 0) + 1
        var p = startPage.coerceAtLeast(0)
        while (p <= maxPage) {
            val g = grid(p)
            for (r in 0..(rows - sy)) for (c in 0..(cols - sx)) if (free(g, c, r, sx, sy, cols, rows)) return Triple(p, c, r)
            p++
        }
        return Triple(maxPage, 0, 0)
    }

    fun compactPages(items: List<HomeItem>): List<HomeItem> {
        val pages = items.map { it.page }.distinct().sorted()
        val map = pages.withIndex().associate { it.value to it.index }
        return items.map { it.copy(page = map.getValue(it.page)) }
    }

    /**
     * Strict variant used for resizing: [moving] takes its new cells, every overlapped item on the same page is moved
     * to the nearest vacant cells ON THAT PAGE. If any of them can't be re-seated, returns null (resize not allowed).
     */
    fun tryPlace(items: List<HomeItem>, moving: HomeItem, cols: Int, rows: Int): List<HomeItem>? {
        if (moving.spanX < 1 || moving.spanY < 1 || moving.col < 0 || moving.row < 0 ||
            moving.col + moving.spanX > cols || moving.row + moving.spanY > rows) return null
        val g = Array(rows) { BooleanArray(cols) }
        mark(g, moving.col, moving.row, moving.spanX, moving.spanY)
        val others = items.filter { it.id != moving.id }
        val onPage = others.filter { it.page == moving.page }.map { clamp(it, cols, rows) }
            .sortedWith(compareBy({ it.row }, { it.col }))
        val keep = ArrayList<HomeItem>()
        val displaced = ArrayList<HomeItem>()
        for (o in onPage) {
            if (free(g, o.col, o.row, o.spanX, o.spanY, cols, rows)) { mark(g, o.col, o.row, o.spanX, o.spanY); keep.add(o) }
            else displaced.add(o)
        }
        val moved = ArrayList<HomeItem>()
        for (o in displaced) {
            var best: IntArray? = null
            var bestD = Int.MAX_VALUE
            for (r in 0..(rows - o.spanY)) for (c in 0..(cols - o.spanX)) {
                if (free(g, c, r, o.spanX, o.spanY, cols, rows)) {
                    val dc = c - o.col; val dr = r - o.row
                    val d = dc * dc + dr * dr
                    if (d < bestD) { bestD = d; best = intArrayOf(c, r) }
                }
            }
            val b = best ?: return null
            mark(g, b[0], b[1], o.spanX, o.spanY)
            moved.add(o.copy(col = b[0], row = b[1]))
        }
        return others.filter { it.page != moving.page } + keep + moved + moving
    }
}

enum class Edge { L, R, T, B, TL, TR, BL, BR }

class ResizeResult(val col: Int, val row: Int, val sx: Int, val sy: Int, val snapped: Rect, val raw: Rect)

/** Edge/corner drag -> snapped cell rectangle (opposite edges stay fixed) plus the raw finger rectangle in grid px. */
fun resizeCandidate(base: HomeItem, e: Edge, d: Offset, cw: Float, ch: Float, cols: Int, rows: Int): ResizeResult {
    val mL = e == Edge.L || e == Edge.TL || e == Edge.BL
    val mR = e == Edge.R || e == Edge.TR || e == Edge.BR
    val mT = e == Edge.T || e == Edge.TL || e == Edge.TR
    val mB = e == Edge.B || e == Edge.BL || e == Edge.BR
    var l = base.col * cw; var r = (base.col + base.spanX) * cw
    var t = base.row * ch; var b = (base.row + base.spanY) * ch
    if (mL) l += d.x; if (mR) r += d.x; if (mT) t += d.y; if (mB) b += d.y
    var gl = base.col; var gr = base.col + base.spanX
    var gt = base.row; var gb = base.row + base.spanY
    if (mL) gl = (l / cw).roundToInt().coerceIn(0, gr - 1)
    if (mR) gr = (r / cw).roundToInt().coerceIn(gl + 1, cols)
    if (mT) gt = (t / ch).roundToInt().coerceIn(0, gb - 1)
    if (mB) gb = (b / ch).roundToInt().coerceIn(gt + 1, rows)
    return ResizeResult(gl, gt, gr - gl, gb - gt, Rect(gl * cw, gt * ch, gr * cw, gb * ch), Rect(l, t, maxOf(r, l + 8f), maxOf(b, t + 8f)))
}
