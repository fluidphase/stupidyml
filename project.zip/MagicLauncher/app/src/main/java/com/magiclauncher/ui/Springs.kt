package com.magiclauncher.ui

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween

/** Material-3 motion curves. Every timed animation in the launcher uses one of these (nothing is linear). */
object Easings {
    val Standard = CubicBezierEasing(0.4f, 0.0f, 0.2f, 1.0f)
    val Emphasized = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)
    val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0.0f, 0.8f, 0.15f)
}

object Springs {
    /** LowBouncy + StiffnessLow: swipes, drops, folder expansion, dock. */
    fun <T> page(): SpringSpec<T> = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow)
    /** Eased tween for layout changes: item displacement, folder / widget resizing. */
    fun <T> shift(): TweenSpec<T> = tween(durationMillis = 340, easing = Easings.Emphasized)
    fun <T> pop(): SpringSpec<T> = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
}
