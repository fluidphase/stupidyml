package com.magiclauncher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class SetupStep(val title: String, val desc: String, val done: Boolean, val button: String, val onClick: () -> Unit)

/** First-run guide: staggered spring entrance, animated check marks as each permission is granted. */
@Composable
fun SetupSheet(steps: List<SetupStep>, onDone: () -> Unit) {
    var card by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { card = true }
    val cs by animateFloatAsState(if (card) 1f else 0.85f, Springs.page(), label = "setupCard")
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.graphicsLayer { scaleX = cs; scaleY = cs; alpha = ((cs - 0.85f) / 0.15f).coerceIn(0f, 1f) }
                .widthIn(max = 620.dp).fillMaxWidth(0.85f)
                .clip(RoundedCornerShape(36.dp)).background(Color(0xF2181A20)).padding(28.dp)
        ) {
            Text("Set up Magic Launcher", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text("Optional, but unlocks the full experience.", color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            steps.forEachIndexed { i, s -> StepRow(i, s) }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onDone, modifier = Modifier.align(Alignment.End)) { Text("Done") }
        }
    }
}

@Composable
private fun StepRow(index: Int, s: SetupStep) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(120L + index * 90L); shown = true }
    val p by animateFloatAsState(if (shown) 1f else 0f, Springs.page(), label = "stepIn")
    val check by animateFloatAsState(if (s.done) 1f else 0f, Springs.pop(), label = "check")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .graphicsLayer { alpha = p.coerceIn(0f, 1f); translationY = (1f - p) * 60f }
            .clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.07f)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF3DBE6B).copy(alpha = 0.25f + 0.75f * check)),
            contentAlignment = Alignment.Center
        ) { Text("✓", color = Color.White, fontSize = 16.sp, modifier = Modifier.graphicsLayer { scaleX = check; scaleY = check }) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, color = Color.White, fontWeight = FontWeight.Medium)
            Text(s.desc, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
        if (!s.done) Button(onClick = s.onClick) { Text(s.button) }
    }
}
