package com.magiclauncher.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

/** Counts active notifications per package -> red badges on icons and folders (needs Notification access). */
class BadgeService : NotificationListenerService() {
    override fun onListenerConnected() = refresh()
    override fun onListenerDisconnected() { counts.value = emptyMap() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val m = HashMap<String, Int>()
        try {
            activeNotifications?.forEach { n ->
                if (!n.isOngoing && (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0) {
                    m[n.packageName] = (m[n.packageName] ?: 0) + 1
                }
            }
        } catch (e: Exception) { /* ignore */ }
        counts.value = m
    }

    companion object { val counts = MutableStateFlow<Map<String, Int>>(emptyMap()) }
}
