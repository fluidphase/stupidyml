package com.magiclauncher.data

import android.content.Context
import com.magiclauncher.model.*
import org.json.JSONArray
import org.json.JSONObject

/** Persists home items + dock (as JSON in SharedPreferences, no extra dependencies). */
class LayoutRepository(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("launcher_layout", Context.MODE_PRIVATE)

    fun save(items: List<HomeItem>, dock: List<String>) {
        val arr = JSONArray()
        items.forEach { arr.put(enc(it)) }
        prefs.edit().putString("items", arr.toString()).putString("dock", JSONArray(dock).toString()).apply()
    }

    fun load(): Pair<List<HomeItem>, List<String>>? {
        val s = prefs.getString("items", null) ?: return null
        return try {
            val arr = JSONArray(s)
            val items = (0 until arr.length()).map { dec(arr.getJSONObject(it)) }
            val d = JSONArray(prefs.getString("dock", "[]"))
            items to (0 until d.length()).map { d.getString(it) }
        } catch (e: Exception) { null }
    }

    private fun enc(i: HomeItem): JSONObject = JSONObject().apply {
        put("id", i.id); put("kind", i.kind.name); put("page", i.page); put("col", i.col); put("row", i.row)
        put("sx", i.spanX); put("sy", i.spanY); put("key", i.key ?: ""); put("title", i.title)
        put("style", i.folderStyle.name)
        put("children", JSONArray(i.children))
        val w = JSONArray()
        i.widgets.forEach { w.put(JSONObject().put("id", it.appWidgetId).put("magic", it.magic?.name ?: "")) }
        put("widgets", w)
    }

    private fun dec(o: JSONObject): HomeItem {
        val ch = o.getJSONArray("children")
        val ws = o.getJSONArray("widgets")
        return HomeItem(
            id = o.getString("id"),
            kind = ItemKind.valueOf(o.getString("kind")),
            page = o.getInt("page"), col = o.getInt("col"), row = o.getInt("row"),
            spanX = o.getInt("sx"), spanY = o.getInt("sy"),
            key = o.getString("key").ifEmpty { null },
            children = (0 until ch.length()).map { ch.getString(it) },
            title = o.optString("title"),
            folderStyle = FolderStyle.valueOf(o.getString("style")),
            widgets = (0 until ws.length()).map {
                val w = ws.getJSONObject(it)
                val m = w.optString("magic")
                WidgetRef(w.getInt("id"), MagicWidgetType.entries.firstOrNull { t -> t.name == m })
            }
        )
    }
}
